/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Taller;

/**
 *
 * @author inaki
 */
public class Vehiculo {
    private String marca;
    private String modelo;
    private String matricula;

    public Vehiculo(String matricula, String marca, 
                     String modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
    }
    
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String Matricula) {
        this.matricula = Matricula;
    }
    
    public String getMarca() {
        return marca;
    }
    public void setMarca(String Marca) {
        this.marca = Marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String Modelo) {
        this.modelo = Modelo;
    }

}
