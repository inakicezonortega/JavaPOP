
package Taller;

import java.util.Scanner;

public class tallerMain {

  public static void main(String[] args) {
        int num_piezas = leerNum();
        //piezas[][] = new String[num_piezas] ;
    }
    
    public static void  pedirPiezas(int num_piezas,String piezas[]){
        for (int i = 0; i != num_piezas; i++){
            String nombre_pieza = leerString();
            double coste_pieza = leerNum();
            Pieza pieza = new Pieza(nombre_pieza,coste_pieza);
            //piezas[i] = pieza;
            
        }
    
    //return coche;
    }
    public static int leerNum(){
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Introduce tu numero:");
        int num = entrada.nextInt();
        
        return num;
    }
    public static String leerString(){
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Introduce tu numero:");
        String nombre = entrada.nextLine();
        
        return nombre;
    }
}
