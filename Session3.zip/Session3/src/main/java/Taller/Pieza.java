
package Taller;

public class Pieza {
    private String nombre;
    private double coste;
    
    public Pieza(String nombre,double coste){
        this.nombre = nombre;
        this.coste = coste;
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public double getCoste(){
        return coste;
    }
    public void setCoste(double coste){
        this.coste = coste;
    }

    @Override
    public String toString() {
        return "El nombre es "+nombre+"\nEl coste es "+ coste; //To change body of generated methods, choose Tools | Templates.
    }
}
