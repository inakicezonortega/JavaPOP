/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Taller;

/**
 *
 * @author inaki
 */
public class Taller {
    
    private String nombre;
    private String telefono;
    private String coste_hora;

    public Taller(String nombre, String telefono, String coste_hora) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.coste_hora = coste_hora;
    }

    public String getCoste_hora() {
        return coste_hora;
    }
    public void setCoste_hora(String coste_hora) {
        this.coste_hora = coste_hora;
    }
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

}
