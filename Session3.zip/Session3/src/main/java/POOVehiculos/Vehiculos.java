
package POOVehiculos;

public class Vehiculos {
    
    private String marca;
    private String modelo;
    private String matricula;
    private int marcha;
    private int velocidad;

    public Vehiculos(String matricula, String marca, 
                     String modelo, int marcha) {
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.marcha = marcha;
    }
    
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String Matricula) {
        this.matricula = Matricula;
    }
    
    public String getMarca() {
        return marca;
    }
    public void setMarca(String Marca) {
        this.marca = Marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String Modelo) {
        this.modelo = Modelo;
    }

    public int getMarcha() {
        return marcha;
    }
    public int setMarcha(int Marcha) {
        this.marcha = Marcha;
        switch (this.marcha) {
            case 0:
                this.velocidad = 0;
                break;
            case 1:
                this.velocidad = 10;
                break;
            case 2:
                this.velocidad = 30;
                break;
            case 3:
                this.velocidad = 60;
                break;
            case 4:
                this.velocidad = 90;
                break;
            case 5:
                this.velocidad = 120;
                break;
            
        }
        return velocidad;
    }
    
    @Override
    public String toString() {
        return "Matricula "+matricula+" Marca "+marca+" Modelo "+modelo+
               " Marcha "+marcha+" Velocidad "+velocidad;
    }
}
