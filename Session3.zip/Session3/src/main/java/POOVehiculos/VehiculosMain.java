
package POOVehiculos;


public class VehiculosMain {

    public static void main(String[] args) {
        Vehiculos v1 = new Vehiculos("1028LBK","Mazda","3",2);
        System.out.print(v1.toString());
    }
    
}
